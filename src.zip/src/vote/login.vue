<template>
  <div>
  		login
  		<title></title>
  </div>
</template>

<script>
	import title from './title.vue';
	export default {
	  name: 'login',
		data() {
				return {
		
				}
		},
		props: {
			
		},
		computed: {},
		components: {
			title
		},
		created() {},
		methods: {}
	}
</script>