<template>
	<div class="login">
		<div class="top">
			title
			<span>ghgh</span>
		</div>
	</div>
</template>

<script>
	export default {
		name: 'page-title',
		data() {

		}
		/*props: ['returnShow', 'title', 'btnName', 'funUrl'],
		methods: {
			funOnClick() {
				this.$router.push({
					path: '/login',
					name: 'login' /*要跳转的路径的 name,在 router文件夹下的 index.js 文件内找
				})
			}
		}*/

	}
</script>