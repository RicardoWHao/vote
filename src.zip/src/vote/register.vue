<template>
</template>

<script>
export default {
  name: 'register',
  data () {
      
    }
  }, 
  props: {},
  computed: {},
  components:{},
  created(){},
  methods：{}

}

<style>
</style>