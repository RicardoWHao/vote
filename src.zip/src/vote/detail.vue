<template>
  <div>
  </div>
</template>

<script>
export default {
  name: 'detail',
  data () {
      
    }
  }, 
  props: {},
  computed: {},
  components:{},
  created(){},
  methods：{}

}
</script>

<style lang="scss" scoped>

</style>
